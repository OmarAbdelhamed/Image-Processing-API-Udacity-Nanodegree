export interface QueryInterface {
  width?: string;
  height?: string;
  name?: string;
}
export interface resizeInterface {
  name: string;
  width: number;
  height: number;
  output: string;
}
